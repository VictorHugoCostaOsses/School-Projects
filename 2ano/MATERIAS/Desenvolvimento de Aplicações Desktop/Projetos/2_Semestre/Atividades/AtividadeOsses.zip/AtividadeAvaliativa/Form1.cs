﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeAvaliativa
{
    public partial class Form1 : Form
    {
        double valor_veiculo;
        int n;
        int x1 = 1;
        int x2 = 2;
        MySqlConnection con; 
        DateTime inicio, fim;
        public Form1()
        {
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.3;port=3306;User ID=cl18152;database=cl18152;password=cl*07062002");
                MessageBox.Show("Conectado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                valor_veiculo  = 0.04*(Convert.ToInt32(textBox1.Text)) ;
                textBox3.Text = Convert.ToString(valor_veiculo);
            }
            catch(Exception ex)
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioButton2.Checked == true)
                {
                    radioButton1.Checked = false;
                    textBox4.Text = "";
                    
                }
                    if (radioButton1.Checked == true  && textBox3.Text != "")
                {
                    textBox4.Text = Convert.ToString(valor_veiculo - valor_veiculo*0.1);
                    n = 1;
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                con.Close();
            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked == true)
                {
                    radioButton2.Checked = false;
                    textBox5.Text = "";
                 
                }
                if (radioButton2.Checked == true && textBox3.Text != "")
                {
                    textBox5.Text = Convert.ToString(valor_veiculo / 3);
                    n = 2;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                con.Close();
            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {


 try//1
 {
     con.Open();
     MySqlCommand inserir = new MySqlCommand("insert into VEICULO(PK,valor_veiculo,valor_imposto,forma_pagamento) values(" +textBox6.Text +",'" + textBox1.Text + "','" + Convert.ToString(textBox3.Text)+ "','" + Convert.ToString(n) + "')", con);
     inserir.ExecuteNonQuery();
 }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }//1

            try//2
            {
                con.Open();
                if (n == 1)
                {
              MySqlCommand inserirPagamento = new MySqlCommand("insert into PAGAMENTO(qtd_parcela_paga)values(" +  x1 + ")", con);
                inserirPagamento.ExecuteNonQuery();
                }
                 else if (n == 2)
                {
         MySqlCommand inserirPagamento2 = new MySqlCommand("insert into PAGAMENTO(qtd_parcela_paga)values(" + x2 + ")");
         inserirPagamento2.ExecuteNonQuery();
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }//2



            try//3
            {
                con.Open();
                MySqlCommand inserir2 = new MySqlCommand("insert into PAGAMENTO(placa) values=(" + Convert.ToInt32(textBox6.Text) + ")", con);
                inserir2.ExecuteNonQuery();
               
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
                {
                con.Close();
            }//3
        }


        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";
            textBox3.Text = "";
            textBox6.Text = "";
            textBox4.Text = "";
            textBox5.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand busca = new MySqlCommand("Select forma_pagamento from VEICULO where =" + textBox7.Text,con);
                MySqlDataReader leitura = busca.ExecuteReader();

                if (leitura.Read())
                {
                    int escolha = Convert.ToInt32(leitura["forma_pagamento"].ToString());
                    con.Close();

            if (escolha == 1)
            {
            con.Open();
          MySqlCommand busca2 = new MySqlCommand("Select PAGAMENTO.qtd_parcela_paga from PAGAMENTO,VEICULO where VEICULO.PK =" + textBox7.Text,con);
                            MySqlDataReader leitura2 = busca2.ExecuteReader();
                        leitura2.Read();
                            textBox8.Text = leitura2["qtd_parcela_paga"].ToString();
                        con.Close();
                    }
                        else
                        {
                        con.Open();
                       MySqlCommand busca3 = new MySqlCommand("Select PAGAMENTO.qtd_parcela_paga from PAGAMENTO,VEICULO where VEICULO.PK=" + textBox7.Text,con);
                        MySqlDataReader leitura3 = busca3.ExecuteReader();
                        leitura3.Read();
                        textBox8.Text = leitura3["qtd_parcela_paga"].ToString();
                        con.Close();
                        }
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
          
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
            con.Open();
            MySqlCommand pagamento = new MySqlCommand("select PAGAMENTO.qtd_parcela_paga from PAGAMENTO INNER JOIN VEICULO ON PK.VEICULO=" + textBox7.Text, con);
            MySqlDataReader result = pagamento.ExecuteReader();
        
            try
            {
                if(result.Read())
                {
                    con.Close();
                    int x = Convert.ToInt32(result["qtd_parcela_paga"].ToString());
                    if (x != 0)
                    {
                        x--;
                        con.Open();
                        MySqlCommand comando = new MySqlCommand("update PAGAMENTO set qtd_parcela_paga =" + x + "where VEICULO.PK  =" + int.Parse(textBox7.Text),con);
                        comando.ExecuteNonQuery();
                        textBox8.Text = Convert.ToString(x);
                        con.Close();
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());

            }
            finally
            {
                con.Close();
            }
        }

        private void tabPage1_Click(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            fim = DateTime.Now;
            TimeSpan dif = fim.Subtract(inicio);
            label6.Text = dif.ToString("hh\\:mm\\:ss");
        }
    }
}
