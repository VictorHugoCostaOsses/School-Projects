﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace AtividadeAvaliativa
{
    public partial class Form1 : Form
    {
        double valor_veiculo;
        int n;
        MySqlConnection con; 
        DateTime inicio, fim;
        public Form1()
        {
            InitializeComponent();
            try
            {
                con = new MySqlConnection("server=143.106.241.1;port=3306;User ID=cl18152;database=cl18152;password=cl*07062002");
                MessageBox.Show("Conectado com sucesso!");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
            
        }

        private void Form1_Load(object sender, EventArgs e)
        {
        
        }

        private void tabPage2_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
               
                valor_veiculo  = 0.04*(Convert.ToInt32(textBox1.Text)) ;
                textBox3.Text = Convert.ToString(valor_veiculo);
            }
            catch(Exception ex)
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
        }

        private void radioButton1_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioButton2.Checked == true)
                {
                    radioButton1.Checked = false;
                    textBox4.Text = "";
                   
                }
                    if (radioButton1.Checked == true  && textBox3.Text != "")
                {
                    textBox4.Text = Convert.ToString(valor_veiculo - valor_veiculo*0.1);
                    n = 1;
                }
                
            }
            catch(Exception ex)
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {

            }
        }

        private void textBox5_TextChanged(object sender, EventArgs e)
        {

        }

        private void radioButton2_CheckedChanged(object sender, EventArgs e)
        {
            try
            {
                if (radioButton1.Checked == true)
                {
                    radioButton2.Checked = false;
                    textBox5.Text = "";
                   
                }
                if (radioButton2.Checked == true && textBox3.Text != "")
                {
                    textBox5.Text = Convert.ToString(valor_veiculo / 3);
                    n = 2;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("dsfsf", "fdsfs", MessageBoxButtons.OK, MessageBoxIcon.Warning);
            }
            finally
            {

            }
        }

        private void maskedTextBox1_MaskInputRejected(object sender, MaskInputRejectedEventArgs e)
        {

        }

        private void label16_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
   MySqlCommand inserir = new MySqlCommand("insert into VEICULO(PK,valor_veiculo,valor_imposto,forma_pagamento) values"+"("+textBox6.Text+","+textBox1.Text+","+textBox3.Text+","+n+")",con);
      inserir.ExecuteNonQuery();
                con.Close();
               

                if(n==1)
                {
                    con.Open();
                    MySqlCommand inserirPagamento = new MySqlCommand("insert into PAGAMENTO(qtd_parcela_paga)values" + "(" + 3 );
                    inserirPagamento.ExecuteNonQuery();
                    con.Close();

                }
                if (n == 2)
                {
                    con.Open();
                    MySqlCommand inserirPagamento2 = new MySqlCommand("insert into PAGAMENTO(qtd_parcela_paga)values" + "(" + 1);
                    inserirPagamento2.ExecuteNonQuery();
                    con.Close();
                }

            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            textBox1.Text = "";

            textBox3.Text = "";

            textBox6.Text = "";

            textBox4.Text = "";

            textBox5.Text = "";
            radioButton1.Checked = false;
            radioButton2.Checked = false;
        }

        private void button4_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
                MySqlCommand busca = new MySqlCommand("Select forma_pagamento from VEICULO where =" + textBox7.Text,con);
                MySqlDataReader leitura = busca.ExecuteReader();

                int escolha = Convert.ToInt32(leitura["forma_pagamento"].ToString());

                if (leitura.Read())
                {
                        if (escolha == 1)
                    {
                            MySqlCommand busca2 = new MySqlCommand("Select qtd_parcela_paga from PAGAMENTO where PK from VEICULO =" +textBox7.Text);
                            MySqlDataReader leitura2 = busca2.ExecuteReader();
                            textBox8.Text = leitura2["qtd_parcela_paga"].ToString();
                    }
                        else
                        {
                            MySqlCommand busca3 = new MySqlCommand("Select qtd_parcela_paga.PAGAMENTO from PAGAMENTO,VEICULO where PK.VEICULO from VEICULO =" + textBox7.Text);
                            MySqlDataReader leitura2 = busca3.ExecuteReader();
                            textBox8.Text = leitura2["qtd_parcela_paga"].ToString();
                        }
                }
                else
                {
                    MessageBox.Show("ERW");
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
            try
            {
                con.Open();
            }
            catch(Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            finally
            {
                con.Close();
            }
          
        }

        private void textBox9_TextChanged(object sender, EventArgs e)
        {

        }

        private void button5_Click(object sender, EventArgs e)
        {
       
        }

        private void timer1_Tick(object sender, EventArgs e)
        {
            fim = DateTime.Now;
            TimeSpan dif = fim.Subtract(inicio);
            label6.Text = dif.ToString("hh\\:mm\\:ss");
        }
    }
}
